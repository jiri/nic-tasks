# JS task

- First, complete the css_task that comprises a base for these tasks.

## Basic part

- The application works as a filter of the searched books. When the page is opened or refreshed (and also when a search is performed with an empty search bar), all the books are shown in an aplhabetical order.
- When the search is submitted, only books that contain the searched string in the book name will be displayed.
- Improve the search in such way, that the string will be searched for in the fields selected in the combo box.
- Update the count of the books shown in the footer according to the currently displayed books.

## Bonus part

- Search results prioritize (show first) books that start with the search string.
- When "All" is selected in the combo box, the search will apply to all fields ("Author", "Name" and "Category")
- Implement search with regex (e.g. some of the characters can be replace with symbols like * . ? or other regex patterns). Search by regex is used only when the user checks the checkbox in the header.
