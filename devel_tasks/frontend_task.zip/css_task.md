# CSS task

Adjust page to the requirements below:

- The webpage has 3 parts – a header, footer and main content.
- The header contains a search bar, combo box with "Name", "Author", "Author and name", "Category", "All" items, checkbox with label "Use regex" and button with text "Search"
- Main content contains a list of books which has been included in index.html.
- The list of books is divided into 3 columns.
- First, only the books' names are displayed. Upon hovering over a book name (bonus: upon clicking on a book name), the name is displayed over all the three columns. Below the book name, there are other information about the book shown. On the left side, there is a text (author, category) and on the right side, there is an image of the book. Other books are shown above and below the selected book.
- The header and footer have same (appropriate) height and it is visible the whole time during page scrolling.
- The footer contains the text "Count of searched items X/Y" where X is the count of the currently showed (it means searched) books and Y is the total count of the books. If you are not solving JS task then X and Y is same.
