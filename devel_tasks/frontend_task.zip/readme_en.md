# Readme
- The index.html file includes basic data from which you should build the app. The file can be modified as necessary.
- If you want, you can use any framework. The content of `body` from index.html can be used at another place (briefly describe this procedure).

# Description of the format of the data in `body`
- Every book is enclosed in an `article` element which contains other information about the book. See next points.
- The `details` element contains a `summary` element with the book name. Other information about the book (e.g. author, category, etc.) are enclosed separetely in a `var` element and their name is determined by a `data-type` attribute.
- The `figure` element contains an image.
- You can see a short example below.


```
<article>
    <figure>
        <img src="http://ecx.images-amazon.com/images/I/4189WdAPk7L.jpg" alt="0470288574.jpg image" width="304" height="228"/>
        <figcaption>0470288574.jpg image</figcaption>
    </figure>
    <details>
        <summary>Geographic Information Analysis</summary>
        <var data-type="indexId">470288574</var>
        <var data-type="author">David O'Sullivan</var>
        <var data-type="categoryId">10</var>
        <var data-type="category">Engineering &amp; Transportation</var>
    </details>
</article>
```
